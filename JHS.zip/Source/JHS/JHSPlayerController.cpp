#include "Player/JHSPlayerController.h"
#include "UI/JHSChatInput.h"
#include "Kismet/KismetSystemLibrary.h"
#include "EngineUtils.h"
#include "Kismet/GameplayStatics.h"
#include "Game/JHSGameModeBase.h"
#include "JHSPlayerState.h"
#include "Net/UnrealNetwork.h"
#include "JHS.h"

AJHSPlayerController::AJHSPlayerController()
{
	bReplicates = true;
}

void AJHSPlayerController::BeginPlay()
{
	Super::BeginPlay();

	if (IsLocalController() == false)
	{
		return;
	}

	FInputModeUIOnly InputModeUIOnly;
	SetInputMode(InputModeUIOnly);

	if (IsValid(ChatInputWidgetClass) == true)
	{
		ChatInputWidgetInstance = CreateWidget<UJHSChatInput>(this, ChatInputWidgetClass);

		if (IsValid(ChatInputWidgetInstance) == true)
		{
			ChatInputWidgetInstance->AddToViewport();
		}

		if (IsValid(NotificationTextWidgetClass) == true)
		{
			NotificationTextWidgetInstance = CreateWidget<UUserWidget>(this, NotificationTextWidgetClass);
			if (IsValid(NotificationTextWidgetInstance) == true)
			{
				NotificationTextWidgetInstance->AddToViewport();
			}
		}
	}
}

void AJHSPlayerController::SetChatMessageString(const FString& InChatMessageString)
{
	ChatMessageString = InChatMessageString;

	if (IsLocalController() == true)
	{
		AJHSPlayerState* JHSPC = GetPlayerState<AJHSPlayerState>();
		if (IsValid(JHSPC) == true)
		{
			FString CombinedMessageString = JHSPC->GetPlayerInfoString() + TEXT(": ") + InChatMessageString;

			ServerRPCPrintChatMessageString(CombinedMessageString);
		}
	}
}

void AJHSPlayerController::PrintChatMessageString(const FString& InChatMessageString)
{
	JHSFunctionLibrary::MyPrintString(this, InChatMessageString, 10.f);
}

void AJHSPlayerController::GetLifetimeReplicatedProps(TArray<class FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);

	DOREPLIFETIME(ThisClass, NotificationText);
}

void AJHSPlayerController::ServerRPCPrintChatMessageString_Implementation(const FString& InChatMessageString)
{
	AGameModeBase* GM = UGameplayStatics::GetGameMode(this);
	if (IsValid(GM) == true)
	{
		AJHSGameModeBase* JHSGM = Cast<AJHSGameModeBase>(GM);
		if (IsValid(JHSGM) == true)
		{
			JHSGM->PrintChatMessageString(this, InChatMessageString);
		}
	}
}

void AJHSPlayerController::ClientRPCPrintChatMessageString_Implementation(const FString& InChatMessageString)
{
	PrintChatMessageString(InChatMessageString);
}