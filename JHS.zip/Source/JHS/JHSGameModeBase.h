#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameModeBase.h"
#include "JHSGameModeBase.generated.h"

class AJHSPlayerController;

UCLASS()
class JHS_API AJHSGameModeBase : public AGameModeBase
{
	GENERATED_BODY()

public:

	virtual void BeginPlay() override;

	virtual void OnPostLogin(AController* NewPlayer) override;

	FString GenerateSecretNumber();

	bool IsGuessNumberString(const FString& InNumberString);

	FString JudgeResult(const FString& InSecretNumberString, const FString& InGuessNumberString);

	void PrintChatMessageString(AJHSPlayerController* InCahttingPlayerController, const FString& InChatMessageString);

	void IncreaseGuessCount(AJHSPlayerController* InChattingPlayerController);

	void ResetGame();

	void JudgeGame(AJHSPlayerController* InChattingPlayerController, int InStrikeCount);


protected:

	FString SecretNumberString;

	TArray<TObjectPtr<AJHSPlayerController>> AllPlayerControllers;
};