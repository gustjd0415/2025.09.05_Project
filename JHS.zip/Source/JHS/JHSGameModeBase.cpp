#include "Game/JHSGameModeBase.h"

#include "JHSGameStateBase.h"
#include "Player/JHSPlayerController.h"
#include "EngineUtils.h"
#include "Player/JHSPlayerState.h"

void AJHSGameModeBase::BeginPlay()
{
	Super::BeginPlay();

	SecretNumberString = GenerateSecretNumber();
}

void AJHSGameModeBase::OnPostLogin(AController* NewPlayer)
{
	Super::OnPostLogin(NewPlayer);

	AJHSPlayerController* JHSPlayerController = Cast<AJHSPlayerController>(NewPlayer);

	if (IsValid(JHSPlayerController) == true)
	{
		JHSPlayerController->NotificationText = FText::FromString(TEXT("Connected to the game server."));

		AllPlayerControllers.Add(JHSPlayerController);

		AJHSPlayerState* JHSPC = JHSPlayerController->GetPlayerState<AJHSPlayerState>();
		if (IsValid(JHSPC) == true)
		{
			JHSPC->PlayerNameString = TEXT("Player") + FString::FromInt(AllPlayerControllers.Num());
		}

		AJHSGameStateBase* JHSGameStateBase = GetGameState<AJHSGameStateBase>();
		if (IsValid(JHSGameStateBase) == true)
		{
			JHSGameStateBase->MulticastRPCBroadcastLoginMessage(JHSPC->PlayerNameString);
		}
	}
}

FString AJHSGameModeBase::GenerateSecretNumber()
{
	TArray<int32> Numbers;

	for (int32 i = 1; i <= 9; ++i)
	{
		Numbers.Add(i);
	}

	FMath::RandInit(FDateTime::Now().GetTicks());

	Numbers = Numbers.FilterByPredicate([](int32 Num) { return Num > 0; });

	FString Result;

	for (int32 i = 0; i < 3; ++i)
	{
		int32 Index = FMath::RandRange(0, Numbers.Num() - 1);
		Result.Append(FString::FromInt(Numbers[Index]));
		Numbers.RemoveAt(Index);
	}
	return Result;
}

bool AJHSGameModeBase::IsGuessNumberString(const FString& InNumberString)
{
	bool bCanPlay = false;

	do {

		if (InNumberString.Len() != 3)
		{
			break;
		}

		bool bIsUnique = true;
		TSet<TCHAR> UniqueDigits;
		for (TCHAR C : InNumberString)
		{
			if (FChar::IsDigit(C) == false || C == '0')
			{
				bIsUnique = false;
				break;
			}

			UniqueDigits.Add(C);
		}

		if (bIsUnique == false)
		{
			break;
		}

		bCanPlay = true;

	} while (false);

	return bCanPlay;
}

FString AJHSGameModeBase::JudgeResult(const FString& InSecretNumberString, const FString& InGuessNumberString)
{
	int32 StrikeCount = 0, BallCount = 0;

	for (int32 i = 0; i < 3; ++i)
	{
		if (InSecretNumberString[i] == InGuessNumberString[i])
		{
			StrikeCount++;
		}
		else
		{
			FString PlayerGuessChar = FString::Printf(TEXT("%c"), InGuessNumberString[i]);
			if (InSecretNumberString.Contains(PlayerGuessChar))
			{
				BallCount++;
			}
		}
	}

	if (StrikeCount == 0 && BallCount == 0)
	{
		return TEXT("OUT");
	}

	return FString::Printf(TEXT("%dS%dB"), StrikeCount, BallCount);
}


void AJHSGameModeBase::PrintChatMessageString(AJHSPlayerController* InChattingPlayerController,
	const FString& InChatMessageString)
{
	int Index = InChatMessageString.Len() - 3;

	FString GuessNumberString = InChatMessageString.RightChop(Index);

	if (IsGuessNumberString(GuessNumberString) == true)
	{
		FString JudgeResultString = JudgeResult(SecretNumberString, GuessNumberString);

		IncreaseGuessCount(InChattingPlayerController);

		for (TActorIterator<AJHSPlayerController> It(GetWorld()); It; ++It)
		{
			AJHSPlayerController* JHSPC = *It;
			if (IsValid(JHSPC) == true)
			{
				FString CombinedMessageString = InChatMessageString + TEXT(" -> ") + JudgeResultString;
				JHSPC->ClientRPCPrintChatMessageString(CombinedMessageString);

				int32 StrikeCount = FCString::Atoi(*JudgeResultString.Left(1));
				JudgeGame(InChattingPlayerController, StrikeCount);
			}
		}
	}
	else
	{
		for (TActorIterator<AJHSPlayerController> It(GetWorld()); It; ++It)
		{
			AJHSPlayerController* JHSPlayerController = *It;
			if (IsValid(JHSPlayerController) == true)
			{
				JHSPlayerController->ClientRPCPrintChatMessageString(InChatMessageString);
			}
		}
	}
}

void AJHSGameModeBase::IncreaseGuessCount(AJHSPlayerController* InChattingPlayerController)
{
	AJHSPlayerState* JHSPC = InChattingPlayerController->GetPlayerState<AJHSPlayerState>();

	if (IsValid(JHSPC) == true)
	{
		JHSPC->CurrentGuessCount++;
	}
}

void AJHSGameModeBase::ResetGame()
{
	SecretNumberString = GenerateSecretNumber();

	for (const auto& PlayerController : AllPlayerControllers)
	{
		AJHSPlayerState* JHSPC = PlayerController->GetPlayerState<AJHSPlayerState>();
		if (IsValid(JHSPC) == true)
		{
			JHSPC->CurrentGuessCount = 0;
		}
	}
}

void AJHSGameModeBase::JudgeGame(AJHSPlayerController* InChattingPlayerController, int InStrikeCount)
{
	if (3 == InStrikeCount)
	{
		AJHSPlayerState* JHSPC = InChattingPlayerController->GetPlayerState<AJHSPlayerState>();
		for (const auto& JHSPlayerController : AllPlayerControllers)
		{
			if (IsValid(JHSPC) == true)
			{
				FString CombinedMessageString = JHSPC->PlayerNameString + TEXT(" has won the game.");
				JHSPlayerController->NotificationText = FText::FromString(CombinedMessageString);

				ResetGame();
			}
		}
	}
	else
	{
		bool bIsDraw = true;
		for (const auto& JHSPlayerController : AllPlayerControllers)
		{
			AJHSPlayerState* JHSPC = JHSPlayerController->GetPlayerState<AJHSPlayerState>();
			if (IsValid(JHSPC) == true)
			{
				if (JHSPC->CurrentGuessCount < JHSPC->MaxGuessCount)
				{
					bIsDraw = false;
					break;
				}
			}

			if (true == bIsDraw)
			{
				for (const auto& JHSPlayerController_ : AllPlayerControllers)
				{
					JHSPlayerController->NotificationText = FText::FromString(TEXT("Draw..."));

					ResetGame();
				}
			}
		}
	}
}