#include "Game/JHSGameStateBase.h"
#include "Kismet/GameplayStatics.h"
#include "Player/JHSPlayerController.h"

void AJHSGameStateBase::MulticastRPCBroadcastLoginMessage_Implementation(const FString& InNameString)
{
	if (HasAuthority() == false)
	{
		APlayerController* PC = UGameplayStatics::GetPlayerController(GetWorld(), 0);
		if (IsValid(PC) == true)
		{
			AJHSPlayerController* JHSPC = Cast<AJHSPlayerController>(PC);
			if (IsValid(JHSPC) == true)
			{
				FString NotificationString = InNameString + TEXT(" has joined the game.");
				JHSPC->PrintChatMessageString(NotificationString);
			}
		}
	}
}